package com.insurance.insuranceCompany.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.insurance.insuranceCompany.contract.IService;
import com.insurance.insuranceCompany.model.CB;
import com.insurance.insuranceCompany.model.Claim;
import com.insurance.insuranceCompany.model.ClaimApplication;
import com.insurance.insuranceCompany.model.ClaimBills;
import com.insurance.insuranceCompany.model.ClaimHistory;
import com.insurance.insuranceCompany.model.CoveredDiseases;
import com.insurance.insuranceCompany.model.LoginClass;
import com.insurance.insuranceCompany.repository.ClaimsRepository;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import com.insurance.insuranceCompany.repository.PackagesRepository;
import com.insurance.insuranceCompany.repository.PermissionRepository;

@Controller
public class HospitalController {
    private static final Logger logger = LoggerFactory.getLogger(HospitalController.class);

    @Autowired
    IService insuranceService;

    PermissionRepository perrep;
    HttpSession session;
    ClaimsRepository clr;
    NetworkHospitalRepository nhr;
    PackagesRepository pr;

    @Autowired
    public HospitalController(ClaimsRepository clr, NetworkHospitalRepository nhr, PackagesRepository pr,
            HttpSession session, PermissionRepository perrep) {
        this.clr = clr;
        this.nhr = nhr;
        this.pr = pr;
        this.session = session;
        this.perrep = perrep;
    }

    // Get all books
    @GetMapping(value = "/getAllClaims")
    public String getAllClaims(Model model) {
        try {
            ArrayList<Claim> li = (ArrayList<Claim>) insuranceService.getAllClaims();
            model.addAttribute("claims", li);

            logger.info("Retrieved all claims successfully");
            logger.trace("Trace message: Retrieved all claims successfully");

            return "Claims";
        } catch (Exception e) {
            logger.error("Error occurred while getting all claims: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @PostMapping(value = "/viewClaim")
    public String getClaimById(Model model, @RequestParam("clamId") int clamId) {
        try {
            Claim cl = insuranceService.getClaimById(clamId);
            model.addAttribute("claim", cl);

            logger.info("Retrieved claim by ID successfully: {}", clamId);
            logger.trace("Trace message: Retrieved claim by ID successfully: {}", clamId);

            return "viewclaim";
        } catch (Exception e) {
            logger.error("Error occurred while getting claim by ID: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @GetMapping(value = "/getFilteredClaims")
    public String getFilteredClaims(Model model, @RequestParam("status") String status) {
        try {
            ArrayList<Claim> li = (ArrayList<Claim>) insuranceService.getFilteredClaims(status);
            model.addAttribute("claims", li);

            logger.info("Retrieved filtered claims successfully with status: {}", status);
            logger.trace("Trace message: Retrieved filtered claims successfully with status: {}", status);

            return "Claims";
        } catch (Exception e) {
            logger.error("Error occurred while getting filtered claims: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @RequestMapping(value = "/excel", method = RequestMethod.POST)
    public void downloadExcel(@RequestParam("selectedStatus") String status, HttpServletResponse response)
            throws IOException {
        try {
            ArrayList<Claim> Claims = new ArrayList<>();
            if (status.equals("select")) {
                Claims = (ArrayList<Claim>) insuranceService.getAllClaims();
            } else {
                Claims = (ArrayList<Claim>) insuranceService.getFilteredClaims(status);
            }

            // Create an Excel workbook using Apache POI
            Workbook workbook = new XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Claims Data");
            Row headerRow = sheet.createRow(0);

            // Define column headings
            headerRow.createCell(0).setCellValue("Claim_Id");
            headerRow.createCell(1).setCellValue("ClamSource");
            headerRow.createCell(2).setCellValue("ClamType");
            headerRow.createCell(3).setCellValue("ClamDate");
            headerRow.createCell(4).setCellValue("ClamAmountRequestedt");
            headerRow.createCell(5).setCellValue("ClamIplcId");
            headerRow.createCell(6).setCellValue("ClamProcessedAmount");
            headerRow.createCell(7).setCellValue("ClamProcessedDate");
            headerRow.createCell(8).setCellValue("ClamProcessedBy");
            headerRow.createCell(9).setCellValue("ClamRemarks");
            headerRow.createCell(10).setCellValue("ClamStatus");

            int rowIdx = 1;
            for (Claim claim : Claims) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(claim.getClamId());
                row.createCell(1).setCellValue(claim.getClamSource());
                row.createCell(2).setCellValue(claim.getClamType());
                row.createCell(3).setCellValue(claim.getClamDate());
                row.createCell(4).setCellValue(claim.getClamAmountRequested());
                row.createCell(5).setCellValue(claim.getClamIplcId());
                row.createCell(6).setCellValue(claim.getClamProcessedAmount());
                row.createCell(7).setCellValue(claim.getClamProcessedDate());
                row.createCell(8).setCellValue(claim.getClamProcessedBy());
                row.createCell(9).setCellValue(claim.getClamRemarks());
                row.createCell(10).setCellValue(claim.getClamStatus());
            }

            // Set the response headers for Excel download
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=claims.xlsx");

            // Write the Excel data to the response output stream
            OutputStream outputStream = response.getOutputStream();
            workbook.write(outputStream);
            outputStream.close();

            logger.info("Excel file downloaded successfully with status: {}", status);
            logger.trace("Trace message: Excel file downloaded successfully with status: {}", status);
        } catch (Exception e) {
            logger.error("Error occurred while downloading Excel file: {}", e.getMessage());
        }
    }

    @GetMapping(value = "/get")
    public String getAlClaims(Model model) {
        return "SETCLAIMS";
    }

    @RequestMapping(value = "/claimbills", method = RequestMethod.POST)
    public String claimData(@RequestParam("file[]") MultipartFile[] files, @RequestParam("claimAmount[]") int[] amount,
            Claim claim, ClaimApplication application, Model model) {
        try {
            insuranceService.addClaimApplication(application);
            insuranceService.addClaim(claim.getClamIplcId(), application.getClaimAmountRequested());
            Claim clm_id = insuranceService.getClaimByid(claim.getClamIplcId());
            int cid = clm_id.getClamId();
            String uploadDir = "src/main/resources/static/file";
            int i = 0;

            // Create the target directory if it doesn't exist
            Files.createDirectories(Paths.get(uploadDir));

            for (MultipartFile file : files) {
                // Get the original file name
                String fileName = StringUtils.cleanPath(file.getOriginalFilename());

                // Create the target file path within the directory
                Path targetLocation = Paths.get(uploadDir).resolve(fileName);

                // Copy the file to the target location
                Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

                String fn = "file/" + file.getOriginalFilename();

                insuranceService.addClaimBills(file.getOriginalFilename(), fn, cid, amount[i]);
                i++;
            }

            // After successfully storing all files, you can redirect to a success page or return a response accordingly
            return "SETCLAIMS";
        } catch (Exception e) {
            logger.error("Error occurred while processing claim data: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    // Rest of the methods...
	// Insurance----------------------------------------------------------------------------
 // Insurance----------------------------------------------------------------------------
    @PostMapping(value = "/viewdocs")
    public String viewDocs(Model model, @RequestParam("clamId") int clamId) {
        try {
            ArrayList<ClaimBills> cl = insuranceService.viewClaimDocsById(clamId);
            model.addAttribute("claim", cl);

            logger.info("Retrieved claim documents successfully for claim ID: {}", clamId);
            logger.trace("Trace message: Retrieved claim documents successfully for claim ID: {}", clamId);

            return "ViewClaimDocuments";
        } catch (Exception e) {
            logger.error("Error occurred while viewing claim documents: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @GetMapping(value = "/viewClaims")
    public String viewAllClaims(Model model) {
        try {
            ArrayList<Claim> li = (ArrayList<Claim>) insuranceService.viewAllClaims();
            model.addAttribute("claims", li);

            logger.info("Retrieved all claims successfully");
            logger.trace("Trace message: Retrieved all claims successfully");

            return "InsuClaims";
        } catch (Exception e) {
            logger.error("Error occurred while viewing all claims: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @PostMapping(value = "/viewInsuClaim")
    public String viewClaimById(Model model, @RequestParam("clamId") int clamId) {
        try {
            Claim cl = insuranceService.viewClaimById(clamId);
            model.addAttribute("claim", cl);

            logger.info("Retrieved claim by ID successfully: {}", clamId);
            logger.trace("Trace message: Retrieved claim by ID successfully: {}", clamId);

            return "viewInsuclaim";
        } catch (Exception e) {
            logger.error("Error occurred while viewing claim by ID: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @PostMapping(value = "/processClaim")
    public String editClaimById(Model model, @RequestParam("clamId") int clamId,
            @RequestParam("clamRemarks") String clamRemarks, @RequestParam("clamProcessedAmount") String clamProcessedAmount,
            @RequestParam("clamStatus") String clamStatus) {
        try {
            insuranceService.editClaimById(clamId, clamRemarks, clamStatus, clamProcessedAmount);
            Claim claim = insuranceService.viewClaimById(clamId);
            model.addAttribute("claim", claim);

            logger.info("Edited claim by ID successfully: {}", clamId);
            logger.trace("Trace message: Edited claim by ID successfully: {}", clamId);

            return "viewclaim";
        } catch (Exception e) {
            logger.error("Error occurred while editing claim by ID: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    // Rest of the methods...


//=======================================================	
    @GetMapping(value = "/docbills")
    public String viewdocBills(@RequestParam("clbl_billindex") int billIndex, Model model) {
        try {
            ClaimBills li = insuranceService.viewdocBills(billIndex);
            ClaimBills cc = insuranceService.updatedate(li.getBillIndex());
            model.addAttribute("date", cc.getProcessedDate());
            model.addAttribute("claim", li);

            logger.info("Retrieved document bills successfully for bill index: {}", billIndex);
            logger.trace("Trace message: Retrieved document bills successfully for bill index: {}", billIndex);

            return "viewSingleDocs";
        } catch (Exception e) {
            logger.error("Error occurred while viewing document bills: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @GetMapping(value = "/allclaimbills")
    public String viewClaimBills(@RequestParam("claimid") int id, Model model) {
        try {
            model.addAttribute("claimBills", insuranceService.viewClaimDocsById(id));

            logger.info("Retrieved claim bills for claim ID: {}", id);
            logger.trace("Trace message: Retrieved claim bills for claim ID: {}", id);

            return "claimbills";
        } catch (Exception e) {
            logger.error("Error occurred while viewing claim bills: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @GetMapping(value = "/applications")
    public String getApplications(Model model) {
        Object lc = session.getAttribute("login");
        if (lc == null || (int) lc == 0) {
            model.addAttribute("noaccess", "you need to login first");
            model.addAttribute("login", new LoginClass());
            return "loginPage";
        }
        int access = perrep.checkAccess((int) lc, "/applications");
        if (access == 1) {
            try {
                model.addAttribute("claimApplications", insuranceService.getAllApplicantions());

                logger.info("Retrieved all claim applications successfully");
                logger.trace("Trace message: Retrieved all claim applications successfully");

                return "applications";
            } catch (Exception e) {
                logger.error("Error occurred while retrieving claim applications: {}", e.getMessage());

                return "error"; // Handle the error appropriately, e.g., return an error view
            }
        }
        model.addAttribute("noaccess", "you don't have access to the claims section");
        model.addAttribute("hospitalCount", nhr.getHospitalsCount());
        model.addAttribute("packageCount", pr.getPackagesCount());
        return "dashboard";
    }

	//===============================================================================
	
    @GetMapping(value = "/getClaim")
    public String getClaim(@RequestParam("policy") int id, Model model) {	
        try {
            Claim claim = insuranceService.getCliamByPolicy(id);
            insuranceService.updateClaimDate(claim.getClamId());
            model.addAttribute("claim", insuranceService.getCliamByPolicy(id));

            logger.info("Retrieved claim information successfully for policy ID: {}", id);
            logger.trace("Trace message: Retrieved claim information successfully for policy ID: {}", id);

            return "viewclaim";
        } catch (Exception e) {
            logger.error("Error occurred while retrieving claim information: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @GetMapping(value = "/getDiseases")
    public String getCoveredDiseases(@RequestParam("policy") int id, Model model) {
        try {
            List<CoveredDiseases> ls = insuranceService.getAllDiseasesCovered(id);
            model.addAttribute("diseases", ls);

            logger.info("Retrieved covered diseases successfully for policy ID: {}", id);
            logger.trace("Trace message: Retrieved covered diseases successfully for policy ID: {}", id);

            return "diseasescovered";
        } catch (Exception e) {
            logger.error("Error occurred while retrieving covered diseases: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @PostMapping(value = "/updateClaimBill")
    public String updateClaimBill(Model model, CB bill, @RequestParam("claimid") String cid) {
        try {
            logger.info("Updating claim bill for bill index: {}", bill.getBillIndex());
            logger.trace("Trace message: Updating claim bill for bill index: {}", bill.getBillIndex());

            System.out.println(bill.getBillIndex() + "  1000 " + cid);
            System.out.println(bill.getProcessedAmount());
            System.out.println(bill.getRemarks());
            System.out.println(bill.getStatus() + "  1000");
            insuranceService.updateClaimBill(bill, Integer.parseInt(cid));
            model.addAttribute("claim", insuranceService.viewdocBills(bill.getBillIndex()));

            logger.info("Updated claim bill successfully for bill index: {}", bill.getBillIndex());
            logger.trace("Trace message: Updated claim bill successfully for bill index: {}", bill.getBillIndex());

            return "viewSingleDocs";
        } catch (Exception e) {
            logger.error("Error occurred while updating claim bill: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

    @GetMapping(value = "/allrecords")
    public String getHistory(@RequestParam("claimid") int cid, Model model) {
        try {
            List<ClaimHistory> m = insuranceService.getHistory(cid);
            model.addAttribute("claimhistory", m);

            logger.info("Retrieved claim history records successfully for claim ID: {}", cid);
            logger.trace("Trace message: Retrieved claim history records successfully for claim ID: {}", cid);

            return "history";
        } catch (Exception e) {
            logger.error("Error occurred while retrieving claim history records: {}", e.getMessage());

            return "error"; // Handle the error appropriately, e.g., return an error view
        }
    }

}