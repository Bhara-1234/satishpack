package com.insurance.insuranceCompany.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.contract.InsurancePackageRepository;
import com.insurance.insuranceCompany.model.Categories;
import com.insurance.insuranceCompany.model.DiseaseDetails;
import com.insurance.insuranceCompany.model.InsurancePackage;

@Controller
public class InsurancePackageController {
    private static final Logger LOGGER = Logger.getLogger(InsurancePackageController.class.getName());

    private final InsurancePackageRepository insurancePackageRepository;

    @Autowired
    public InsurancePackageController(InsurancePackageRepository insurancePackageRepository) {
        this.insurancePackageRepository = insurancePackageRepository;
    }

    @GetMapping("/list")
    public String getAllInsurancePackages(Model model) {
        try {
            List<InsurancePackage> insurancePackages = insurancePackageRepository.getAllInsurancePackages();
            model.addAttribute("insurancePackages", insurancePackages);
            LOGGER.info("Retrieved all insurance packages successfully.");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while retrieving insurance packages", e);
        }
        return "packages";
    }

    @GetMapping("/diseasedetails/{discId}")
    public String viewDiseseDetails(@PathVariable int discId, Model model) {
        try {
            DiseaseDetails dd = insurancePackageRepository.getDiseaseDetailsById(discId);
            model.addAttribute("diseasedetails", dd);
            LOGGER.info("Retrieved disease details successfully for disease ID: " + discId);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while retrieving disease details", e);
        }
        return "diseasedetails";
    }

    @RequestMapping(value = "/start")
    public String packages() {
        return "redirect:/list";
    }

    @GetMapping("/filteredpackages")
    public String getFilteredPackages(@RequestParam("status") String status, @RequestParam("age") String age,
            Model model) {
        try {
            LOGGER.info("Filtering insurance packages with status: " + status + " and age: " + age);
            
            if ("ALL".equals(status) && age.equals("")) {
                List<InsurancePackage> insurancePackages = insurancePackageRepository.getAllInsurancePackages();
                model.addAttribute("insurancePackages", insurancePackages);
            } else if ("ALL".equals(status) && !age.equals("")) {
                List<InsurancePackage> insurancePackages = insurancePackageRepository
                        .getAllInsurancePackagesByAge(Integer.parseInt(age));
                model.addAttribute("insurancePackages", insurancePackages);
            } else {
                if (age.equals("")) {
                    List<InsurancePackage> insurancePackages = insurancePackageRepository.getPackagesByStatus(status);
                    model.addAttribute("insurancePackages", insurancePackages);
                } else {
                    List<InsurancePackage> packages = insurancePackageRepository.getFilteredPackages(status,
                            Integer.parseInt(age));
                    model.addAttribute("insurancePackages", packages);
                }
            }
            
            LOGGER.info("Filtered insurance packages retrieved successfully.");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while filtering insurance packages", e);
        }
        return "packages";
    }

    @RequestMapping(value = "/excel")
    public void downloadExcel(@RequestParam("status") String status, @RequestParam("age") String age,
            HttpServletResponse response) throws IOException {
        try {
            List<InsurancePackage> insurancePackages = new ArrayList<>();
            
            if ("ALL".equals(status) && age.equals("")) {
                insurancePackages = insurancePackageRepository.getAllInsurancePackages();
            } else if ("ALL".equals(status) && !age.equals("")) {
                insurancePackages = insurancePackageRepository.getAllInsurancePackagesByAge(Integer.parseInt(age));
            } else {
                if (age.equals("")) {
                    insurancePackages = insurancePackageRepository.getPackagesByStatus(status);
                } else {
                    insurancePackages = insurancePackageRepository.getFilteredPackages(status, Integer.parseInt(age));
                }
            }
            
            LOGGER.info("Generated Excel file for insurance packages: " + insurancePackages.size() + " records.");
            
            Workbook workbook = new XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Packages List");
            Row headerRow = sheet.createRow(0);
            
            // Define column headings
            headerRow.createCell(0).setCellValue("PackageId");
            headerRow.createCell(1).setCellValue("PackageTitle");
            headerRow.createCell(2).setCellValue("Description");
            headerRow.createCell(3).setCellValue("Status");
            headerRow.createCell(4).setCellValue("Amount Start Range");
            headerRow.createCell(5).setCellValue("Amount End Range");
            headerRow.createCell(6).setCellValue("Age Limit Start");
            headerRow.createCell(7).setCellValue("Age Limit End");
            
            int rowIdx = 1;
            for (InsurancePackage insurance : insurancePackages) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(insurance.getInspId());
                row.createCell(1).setCellValue(insurance.getInspTitle());
                row.createCell(2).setCellValue(insurance.getInspDescription());
                row.createCell(3).setCellValue(insurance.getInspStatus());
                row.createCell(4).setCellValue(insurance.getInspRangeStart());
                row.createCell(5).setCellValue(insurance.getInspRangeEnd());
                row.createCell(6).setCellValue(insurance.getInspAgeLimitStart());
                row.createCell(7).setCellValue(insurance.getInspAgeLimitEnd());
            }
            
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=packages.xlsx");
            OutputStream outputStream = response.getOutputStream();
            workbook.write(outputStream);
            outputStream.close();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while generating Excel file", e);
        }
    }

    @GetMapping(value = "/diseases/{inspId}/{inspTitle}")
    public String getDiseases(@PathVariable int inspId, @PathVariable String inspTitle, Model model) {
        try {
            List<DiseaseDetails> diseases = insurancePackageRepository.getDiseasesByPackageId(inspId);
            for (DiseaseDetails d : diseases) {
                LOGGER.info(d.toString());
            }
            LOGGER.info("Retrieved diseases for package ID: " + inspId);
            model.addAttribute("inspId", inspId);
            model.addAttribute("inspTitle", inspTitle);
            model.addAttribute("diseases", diseases);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while retrieving diseases", e);
        }
        return "diseasedetails";
    }

    @PostMapping("/addDiseaseBh")
    @ResponseBody
    public String addDisease(@RequestParam String name, String ICDCode, String Description, String inspId) {
        try {
            LOGGER.info("Adding a new disease: name=" + name + ", ICDCode=" + ICDCode + ", Description=" + Description + ", inspId=" + inspId);
            int message = insurancePackageRepository.addDisease(name, ICDCode, Description, "Ac", Integer.parseInt(inspId));
            LOGGER.info("Disease added with message code: " + message);
            if (message == 1)
                return "record added successfully";
            else
                return "error occurred while adding record";
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while adding a new disease", e);
            return "error occurred while adding record";
        }
    }

    @PostMapping("/deleteDiseaseBh")
    @ResponseBody
    public String deleteDisease(@RequestParam int did, int inspId) {
        try {
            LOGGER.info("Deleting disease with ID: " + did + " for inspId: " + inspId);
            int message = insurancePackageRepository.deleteDisease(did, inspId);
            LOGGER.info("Disease deleted with message code: " + message);
            if (message == 1)
                return "record deleted successfully";
            else
                return "error occurred while deleting record";
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while deleting a disease", e);
            return "error occurred while deleting record";
        }
    }

    @PostMapping("/editDiseaseBh")
    @ResponseBody
    public String editDisease(@RequestParam String name, String ICDCode, String Description, String Status, String Id,
            Model model) {
        try {
            LOGGER.info("Editing disease: name=" + name + ", ICDCode=" + ICDCode + ", Description=" + Description + ", Status=" + Status + ", Id=" + Id);
            String message = insurancePackageRepository.editDisease(name, ICDCode, Description, Status, Id);
            LOGGER.info("Disease edited with message: " + message);
            return message;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while editing a disease", e);
            return "error occurred while editing record";
        }
    }

    @GetMapping(value = "/categories/{inspId}/{inspTitle}")
    public String getCategories(@PathVariable int inspId, @PathVariable String inspTitle, Model model) {
        try {
            List<Categories> diseases = insurancePackageRepository.getCategoriesByPackageId(inspId);
            LOGGER.info("Retrieved categories for inspId: " + inspId);
            model.addAttribute("inspId", inspId);
            model.addAttribute("inspTitle", inspTitle);
            model.addAttribute("categories", diseases);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while retrieving categories", e);
        }
        return "Categories";
    }

    @PostMapping("/deleteCategory")
    @ResponseBody
    public String deleteCategory(@RequestParam String cid, String inspId) {
        try {
            LOGGER.info("Deleting category with ID: " + cid + " for inspId: " + inspId);
            int message = insurancePackageRepository.deleteCategory(Integer.parseInt(cid), Integer.parseInt(inspId));
            LOGGER.info("Category deleted with message code: " + message);
            if (message == 1)
                return "record deleted successfully";
            else
                return "error occurred while deleting record";
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while deleting a category", e);
            return "error occurred while deleting record";
        }
    }

    @PostMapping("/addCategory")
    @ResponseBody
    public String addCategory(@RequestParam String Title, String Description, String inspId) {
        try {
            LOGGER.info("Adding a new category: Title=" + Title + ", Description=" + Description + ", inspId=" + inspId);
            int message = insurancePackageRepository.addCategory("", Title, Description, "Ac", Integer.parseInt(inspId));
            LOGGER.info("Category added with message code: " + message);
            if (message == 1)
                return "record added successfully";
            else
                return "error occurred while adding record";
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while adding a new category", e);
            return "error occurred while adding record";
        }
    }

    @PostMapping("/editCategory")
    @ResponseBody
    public String editCategory(@RequestParam String Title, String Description, String Status, String inspId,
            Model model) {
        try {
            LOGGER.info("Editing category: Title=" + Title + ", Description=" + Description + ", Status=" + Status);
            String message = insurancePackageRepository.editCategory(Title, Description, Status);
            LOGGER.info("Category edited with message: " + message);
            model.addAttribute("categories", insurancePackageRepository.getCategoriesByPackageId(Integer.parseInt(inspId)));
            return message;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while editing a category", e);
            return "error occurred while editing record";
        }
    }

    @PostMapping("/deletePackagesBh")
    @ResponseBody
    public String deletePackages(@ModelAttribute("did") String insp) {
        try {
            LOGGER.info("Deleting package with ID: " + insp);
            int message = insurancePackageRepository.deletePackage(Integer.parseInt(insp));
            LOGGER.info("Package deleted with message code: " + message);
            if (message == 1)
                return "record deleted successfully";
            else
                return "error occurred while deleting record";
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while deleting a package", e);
            return "error occurred while deleting record";
        }
    }

    @PostMapping("/editPackageBh")
    @ResponseBody
    public String editPackage(@RequestParam String Id, String title, String Description, String status,
            String rangeStart, String rangeEnd, String ageLimitStrt, String ageLimitEnd, Model model) {
        try {
            LOGGER.info("Editing package: Id=" + Id + ", Title=" + title + ", Description=" + Description + ", Status=" + status + ", RangeStart=" + rangeStart + ", RangeEnd=" + rangeEnd + ", AgeLimitStart=" + ageLimitStrt + ", AgeLimitEnd=" + ageLimitEnd);
            String message = insurancePackageRepository.editPackage(Id, title, Description, status, rangeStart, rangeEnd,
                    ageLimitStrt, ageLimitEnd);
            LOGGER.info("Package edited with message: " + message);
            return message;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while editing a package", e);
            return "error occurred while editing record";
        }
    }

    @PostMapping("/addPackageBh")
    @ResponseBody
    public String addPackage(@RequestBody InsurancePackage insurancePackage, Model model) {
        try {
            LOGGER.info("Received a request to add a new package: " + insurancePackage.toString());
            insurancePackageRepository.addPackage(insurancePackage);
            List<InsurancePackage> insurancePackages = insurancePackageRepository.getAllInsurancePackages();
            model.addAttribute("insurancePackages", insurancePackages);
            LOGGER.info("Added a new insurance package successfully.");
            return "packages"; // You can return a response as needed
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error while adding a new insurance package", e);
            return "error occurred while adding record";
        }
    }
}
