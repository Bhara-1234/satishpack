package com.insurance.insuranceCompany.controller;

import java.time.LocalTime;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.insuranceCompany.model.LoginClass;
import com.insurance.insuranceCompany.repository.EmailRepository;
import com.insurance.insuranceCompany.repository.RepositoryAdmin;

@Controller
public class EmailController {
    private static final Logger logger = LoggerFactory.getLogger(EmailController.class);

    @Autowired
    RepositoryAdmin repadmin;

    private EmailRepository mailService;
    private HttpSession httpSession;

    @Autowired
    public EmailController(EmailRepository mailService, HttpSession httpSession) {
        this.mailService = mailService;
        this.httpSession = httpSession;
    }

    @GetMapping("/email")
    @ResponseBody
    public String email(@RequestParam("to") String to_mail) {
        try {
            String email = to_mail;

            if (mailService.checkMail(email) == 1) {
                httpSession.setAttribute("email", email);
                // storing generated otp
                int OTP = mailService.sendmail(to_mail);
                LocalTime currentTime = LocalTime.now();
                System.out.println(currentTime);
                httpSession.setAttribute("time", currentTime.plusMinutes(5));
                httpSession.setAttribute("OTP", OTP);

                logger.info("Email sent successfully to: {}", email);
                logger.trace("Trace message: Email sent successfully to: {}", email);

                return "Email Sent Successfully";
            } else {
                logger.warn("Email not registered: {}", email);
                return "Email not registered";
            }
        } catch (Exception e) {
            logger.error("Error occurred while sending email: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error message.
            return "Error sending email."; // Example: Return an error message
        }
    }

    @PostMapping(value = "/validateOTP")
    public ModelAndView validateOTP(@RequestParam("otp") String otp, Model model) {
        try {
            model.addAttribute("to", "");
            int OTP = Integer.parseInt(otp);
            ModelAndView mav = new ModelAndView();
            int originalOtp = (Integer) httpSession.getAttribute("OTP");
            String email = (String) httpSession.getAttribute("email");
            LocalTime time = (LocalTime) httpSession.getAttribute("time");
            int comp = time.compareTo(LocalTime.now());
            // checking the otp sent by the user if true returning reset page else need to stay in the same page with error
            // msg
            if (originalOtp == OTP && comp > 0) {
                mav.setViewName("reset");
                mav.addObject("email", email);

                logger.info("Validated OTP for email: {}", email);
                logger.trace("Trace message: Validated OTP for email: {}", email);

                return mav;
            }
            mav.setViewName("forgotPasswordPage");
            if (comp < 0)
                mav.addObject("msg", "OTP expired, please try again..");
            else
                mav.addObject("msg", "Invalid OTP, please try again..");
            mav.addObject("to", email);

            logger.warn("OTP validation failed for email: {}", email);
            return mav;
        } catch (Exception e) {
            logger.error("Error occurred while validating OTP: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return new ModelAndView("error"); // Example: Return an error view
        }
    }

    @PostMapping("/reset")
    public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
            @RequestParam("cnfpwd") String cnfpwd) {
        try {
            System.out.println(email + " " + pwd + " " + cnfpwd);
            int x = repadmin.resetpwd(email, pwd);
            if (x == 1) {
                model.addAttribute("message", "password changed");

                logger.info("Password changed for email: {}", email);
                logger.trace("Trace message: Password changed for email: {}", email);

            } else {
                model.addAttribute("message", "error while password changing");

                logger.error("Error occurred while changing password for email: {}", email);
            }
            model.addAttribute("login", new LoginClass());
            return "loginPage";
        } catch (Exception e) {
            logger.error("Error occurred while resetting password: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }
}
