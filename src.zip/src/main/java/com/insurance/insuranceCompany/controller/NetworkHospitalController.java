package com.insurance.insuranceCompany.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.model.NetworkHospitals;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class NetworkHospitalController {
    private static final Logger LOGGER = LoggerFactory.getLogger(NetworkHospitalController.class);

    @Autowired
    private NetworkHospitalRepository nr;

    @GetMapping(value = "/hospitals")
    public String getAllHospitals(HttpServletRequest request, Model model) {
        try {
            int hospitalCount = nr.getAllHospitals().size();
            model.addAttribute("networkHospital", new NetworkHospitals());
            model.addAttribute("hospitals", nr.getAllHospitals());
            model.addAttribute("hospitalCount", hospitalCount);
            LOGGER.info("Retrieved all network hospitals successfully.");
            return "networkHospitals";
        } catch (Exception e) {
            LOGGER.error("Error while retrieving network hospitals.", e);
            throw e;
        }
    }

    @PostMapping("/addhospital")
    public String addhospital(Model model, @RequestBody NetworkHospitals netHsp) {
        try {
            LOGGER.info("Adding a new network hospital: " + netHsp.toString());
            int x = nr.addHospital(netHsp);
            model.addAttribute("networkHospital", new NetworkHospitals());
            model.addAttribute("hospitals", nr.getAllHospitals());
            if (x == 1) {
                LOGGER.info("Network hospital added successfully.");
                model.addAttribute("msg", "Hospital added successfully");
            } else {
                LOGGER.error("Error occurred while adding network hospital.");
                model.addAttribute("msg", "Error occurred while adding hospital");
            }
            return "networkHospitals";
        } catch (Exception e) {
            LOGGER.error("Error while adding a network hospital.", e);
            throw e;
        }
    }

    @PostMapping("/editHospital")
    public String editHospital(Model model, @ModelAttribute("networkHospital") NetworkHospitals netHsp) {
        try {
            LOGGER.info("Editing network hospital: " + netHsp.toString());
            int x = nr.editHospital(netHsp);
            model.addAttribute("networkHospital", new NetworkHospitals());
            model.addAttribute("hospitals", nr.getAllHospitals());
            if (x == 1) {
                LOGGER.info("Network hospital updated successfully.");
                model.addAttribute("msg", "Hospital updated successfully");
            } else {
                LOGGER.error("Error occurred while updating network hospital.");
                model.addAttribute("msg", "Error occurred while updating hospital");
            }
            return "networkHospitals";
        } catch (Exception e) {
            LOGGER.error("Error while editing a network hospital.", e);
            throw e;
        }
    }

    @PostMapping(value = "/deleteHospital")
    @ResponseBody
    public String deleteHospital(@ModelAttribute("hospitalId") String hid) {
        try {
            LOGGER.info("Deleting network hospital with ID: " + hid);
            int x = nr.deleteHospital(Integer.parseInt(hid));
            if (x == 1) {
                LOGGER.info("Network hospital deleted successfully.");
                return "Hospital deleted successfully...!";
            } else {
                LOGGER.error("Error occurred while deleting network hospital.");
                return "Error occurred";
            }
        } catch (Exception e) {
            LOGGER.error("Error while deleting a network hospital.", e);
            throw e;
        }
    }

    @GetMapping("/getPackages")
    public String getPackages(@RequestParam(name = "hspid") int hspid, Model model) {
        try {
            LOGGER.info("Getting related insurance packages for hospital with ID: " + hspid);
            model.addAttribute("hospid", hspid);
            ArrayList<InsurancePackage> ip = nr.getRelatedPackages(hspid);
            model.addAttribute("packages", ip);
            LOGGER.info("Retrieved related insurance packages successfully.");
            return "hptlRelatedPack";
        } catch (Exception e) {
            LOGGER.error("Error while getting related insurance packages.", e);
            throw e;
        }
    }

    @PostMapping("/addPackage")
    @ResponseBody
    public String addInsurancePackage(@RequestParam String title, @RequestParam String desc,
            @RequestParam String status, @RequestParam long rangeStart, @RequestParam long rangeEnd,
            @RequestParam Integer ageLimitStart, @RequestParam Integer ageLimitEnd, @RequestParam String hospid) {
        try {
            LOGGER.info("Adding a new insurance package: Title=" + title + ", Description=" + desc + ", Status=" + status);
            int message = nr.addPackage(title, desc, status, rangeStart, rangeEnd, ageLimitStart, ageLimitEnd,
                    Integer.parseInt(hospid));
            if (message == 1) {
                LOGGER.info("Insurance package added successfully.");
                return "Record added successfully";
            } else {
                LOGGER.error("Error occurred while adding an insurance package.");
                return "Error occurred while adding record";
            }
        } catch (Exception e) {
            LOGGER.error("Error while adding a new insurance package.", e);
            throw e;
        }
    }

    @PostMapping("/deletePackages")
    @ResponseBody
    public String deletePackages(@RequestParam String did, String hospid) {
        try {
            LOGGER.info("Deleting insurance package with ID: " + did);
            int message = nr.deletePackage(Integer.parseInt(did), Integer.parseInt(hospid));
            if (message == 1) {
                LOGGER.info("Insurance package deleted successfully.");
                return "Record deleted successfully";
            } else {
                LOGGER.error("Error occurred while deleting an insurance package.");
                return "Error occurred while deleting record";
            }
        } catch (Exception e) {
            LOGGER.error("Error while deleting an insurance package.", e);
            throw e;
        }
    }

    @PostMapping("/editPackage")
    @ResponseBody
    public String editPackage(@RequestParam String Id, String title, String Description, String status,
            String rangeStart, String rangeEnd, String ageLimitStrt, String ageLimitEnd, Model model) {
        try {
            LOGGER.info("Editing insurance package: Id=" + Id + ", Title=" + title + ", Description=" + Description + ", Status=" + status);
            String message = nr.editPackage(Id, title, Description, status, rangeStart, rangeEnd, ageLimitStrt,
                    ageLimitEnd);
            LOGGER.info("Insurance package edited with message: " + message);
            return message;
        } catch (Exception e) {
            LOGGER.error("Error while editing an insurance package.", e);
            throw e;
        }
    }

    @GetMapping("/searchbyname")
    public String search(@ModelAttribute("search") String search, Model model) {
        try {
            int hospitalCount = nr.getAllHospitals().size();
            model.addAttribute("networkHospital", new NetworkHospitals());
            model.addAttribute("hospitals", nr.getSearchHospitals(search));
            model.addAttribute("hospitalCount", hospitalCount);
            LOGGER.info("Searched network hospitals by name successfully.");
            return "networkHospitals";
        } catch (Exception e) {
            LOGGER.error("Error while searching network hospitals by name.", e);
            throw e;
        }
    }
}
