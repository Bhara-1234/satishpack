package com.insurance.insuranceCompany.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance.insuranceCompany.model.InsurancePolicy;
import com.insurance.insuranceCompany.repository.InsuranceRepositorySch;

@Controller
public class InsuranceControllerSch {
    private static final Logger logger = LoggerFactory.getLogger(InsuranceControllerSch.class);

    @Autowired
    private InsuranceRepositorySch insu;

    // to view pages
    @GetMapping("/link")
    public String getAllLinks() {
        try {
            logger.trace("Entering getAllLinks method");
            return "Links";
        } catch (Exception e) {
            logger.error("Error occurred in getAllLinks: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    // to view policy
    @GetMapping("/getpolicy")
    public String getAllPolicy(Model m) {
        try {
            logger.trace("Entering getAllPolicy method");
            List<InsurancePolicy> p = insu.ListAllPolicy();
            m.addAttribute("policies", p);
            logger.info("Retrieved {} policies", p.size());
            logger.trace("Exiting getAllPolicy method");
            return "ViewPolicy";
        } catch (Exception e) {
            logger.error("Error occurred in getAllPolicy: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    // to go to create form
    @GetMapping("/insertPolicyForm")
    public String showInsertPolicyForm(Model model) {
        try {
            logger.trace("Entering showInsertPolicyForm method");
            model.addAttribute("policy", new InsurancePolicy());
            logger.trace("Exiting showInsertPolicyForm method");
            return "CreatePolicy";
        } catch (Exception e) {
            logger.error("Error occurred in showInsertPolicyForm: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    // to create a policy at insurance side
    @PostMapping("/insertPolicy")
    public String insertPolicy(@ModelAttribute("policy") InsurancePolicy policy) {
        try {
            logger.trace("Entering insertPolicy method");
            insu.createNewPolicy(policy);
            logger.info("Insurance policy created: Policy ID {}", policy.getIplc_id());
            logger.trace("Exiting insertPolicy method");
            return "redirect:/getpolicy"; // Redirect to a list of policies or another appropriate page
        } catch (Exception e) {
            logger.error("Error occurred while creating insurance policy: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    // to view schedule at insurance side
    @GetMapping("/getpolicySchedule")
    public String getAllPolicySchedule(Model m) {
        try {
            logger.trace("Entering getAllPolicySchedule method");
            m.addAttribute("schedules", insu.ListAllPolicySchedules());
            logger.info("Retrieved all policy schedules");
            logger.trace("Exiting getAllPolicySchedule method");
            return "ViewSchedule";
        } catch (Exception e) {
            logger.error("Error occurred in getAllPolicySchedule: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    // to view policy
    @GetMapping("/updatepolicy")
    public String UpdateFormPolicy(Model m) {
        try {
            logger.trace("Entering UpdateFormPolicy method");
            List<InsurancePolicy> p = insu.ListAllPolicy();
            m.addAttribute("policies", p);
            logger.trace("Exiting UpdateFormPolicy method");
            return "StatusApproval";
        } catch (Exception e) {
            logger.error("Error occurred in UpdateFormPolicy: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @GetMapping("/UpdatestatusPolicy")
    public String updatedversionPolicy(@ModelAttribute("policy") InsurancePolicy policy) {
        try {
            logger.trace("Entering updatedversionPolicy method");
            insu.updateNewPolicy(policy);
            logger.info("Insurance policy updated: Policy ID {}", policy.getIplc_id());
            logger.trace("Exiting updatedversionPolicy method");
            return "redirect:/getpolicy";
        } catch (Exception e) {
            logger.error("Error occurred while updating insurance policy: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @GetMapping("/nonPaymentStatus")
    public String getNonPaymentStatus(@RequestParam("iplcId") int id, Model m) {
        try {
            logger.trace("Entering getNonPaymentStatus method");
            int p = insu.ListNonStatusPayments(id);
            m.addAttribute("policies", p);
            logger.info("Retrieved non-payment status for Policy ID {}", id);
            logger.trace("Exiting getNonPaymentStatus method");
            return "ViewNonPaymentStatus";
        } catch (Exception e) {
            logger.error("Error occurred in getNonPaymentStatus: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @GetMapping("/StatusPaymentById")
    public String getDistinctIplcIds(Model model) {
        try {
            logger.trace("Entering getDistinctIplcIds method");
            List<Integer> distinctIplcIds = insu.findDistinctIds();
            model.addAttribute("distinctIplcIds", distinctIplcIds);
            logger.info("Retrieved distinct Insurance Policy IDs: {}", distinctIplcIds);
            logger.trace("Exiting getDistinctIplcIds method");
            return "StatusById";
        } catch (Exception e) {
            logger.error("Error occurred in getDistinctIplcIds: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @GetMapping("/ScheduleById")
    public String getScheduleDistinctIplcIds(Model model) {
        try {
            logger.trace("Entering getScheduleDistinctIplcIds method");
            List<Integer> distinctIplcIds = insu.findDistinctIds();
            model.addAttribute("distinctIplcIds", distinctIplcIds);
            logger.info("Retrieved distinct Insurance Policy IDs for scheduling: {}", distinctIplcIds);
            logger.trace("Exiting getScheduleDistinctIplcIds method");
            return "ViewScheduleById";
        } catch (Exception e) {
            logger.error("Error occurred in getScheduleDistinctIplcIds: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @GetMapping("/getpolicyScheduleById")
    public String getAllPolicyScheduleById(@RequestParam("iplcId") int id, Model m) {
        try {
            logger.trace("Entering getAllPolicyScheduleById method");
            m.addAttribute("schedules", insu.ListAllPolicySchedulesById(id));
            logger.info("Retrieved policy schedules for Policy ID {}", id);
            logger.trace("Exiting getAllPolicyScheduleById method");
            return "ViewScheduleByIds";
        } catch (Exception e) {
            logger.error("Error occurred in getAllPolicyScheduleById: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }
}
