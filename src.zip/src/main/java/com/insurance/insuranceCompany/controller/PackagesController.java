package com.insurance.insuranceCompany.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.model.Disease;
import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.repository.PackagesRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class PackagesController {
    private static final Logger LOGGER = LoggerFactory.getLogger(PackagesController.class);

    @Autowired
    private PackagesRepository pr;

    @GetMapping("/packages")
    public String getAllPackages(Model model) {
        try {
            model.addAttribute("packages", pr.getAllPackages());
            model.addAttribute("insurancePackage", new InsurancePackage());
            LOGGER.info("Retrieved all packages successfully.");
            return "packages";
        } catch (Exception e) {
            LOGGER.error("Error while retrieving packages.", e);
            throw e;
        }
    }

    @PostMapping("/addpackage")
    public String addhospital(Model model, @ModelAttribute("insurancePackage") InsurancePackage insp) {
        try {
            LOGGER.info("Adding a new insurance package: " + insp.toString());
            int x = pr.addPackage(insp);
            model.addAttribute("packages", pr.getAllPackages());
            model.addAttribute("insurancePackage", new InsurancePackage());
            if (x == 1) {
                LOGGER.info("Insurance package added successfully.");
                model.addAttribute("msg", "Package added successfully");
            } else {
                LOGGER.error("Error occurred while adding an insurance package.");
                model.addAttribute("msg", "Error occurred while adding package");
            }
            return "packages";
        } catch (Exception e) {
            LOGGER.error("Error while adding a new insurance package.", e);
            throw e;
        }
    }

    @PostMapping(value = "/deletePackage")
    @ResponseBody
    public String deleteHospital(@ModelAttribute("packageId") String pid) {
        try {
            LOGGER.info("Deleting insurance package with ID: " + pid);
            int x = pr.deletePackage(Integer.parseInt(pid));
            if (x == 1) {
                LOGGER.info("Insurance package deleted successfully.");
                return "Package deleted successfully...!";
            }
            LOGGER.error("Error occurred while deleting an insurance package.");
            return "Error occurred";
        } catch (Exception e) {
            LOGGER.error("Error while deleting an insurance package.", e);
            throw e;
        }
    }

    @GetMapping(value = "/showDiseases")
    public String showDiseases(@ModelAttribute("packageId") String pid, Model model) {
        try {
            LOGGER.info("Retrieving diseases for package with ID: " + pid);
            ArrayList<Disease> x = pr.showDiseases(Integer.parseInt(pid));
            LOGGER.info("Retrieved diseases for package with ID: " + pid + " successfully.");
            System.out.println(x.get(0));
            model.addAttribute("diseaseslist", x);
            return "diseases";
        } catch (Exception e) {
            LOGGER.error("Error while retrieving diseases for a package.", e);
            throw e;
        }
    }
}
