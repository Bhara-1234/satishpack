package com.insurance.insuranceCompany.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.insurance.insuranceCompany.contract.PaymentRepositoryInterface;
import com.insurance.insuranceCompany.model.LoginClass;
import com.insurance.insuranceCompany.repository.ClaimsRepository;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import com.insurance.insuranceCompany.repository.PackagesRepository;
import com.insurance.insuranceCompany.repository.PermissionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class PaymentController {
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentController.class);

	private PaymentRepositoryInterface pri;
	private ClaimsRepository clr;
	private NetworkHospitalRepository nhr;
	private PackagesRepository pr;
	private HttpSession session;
	private PermissionRepository perrep;

	@Autowired
	public PaymentController(ClaimsRepository clr, NetworkHospitalRepository nhr, PackagesRepository pr,
			HttpSession session, PermissionRepository perrep, PaymentRepositoryInterface pri) {
		this.clr = clr;
		this.nhr = nhr;
		this.pr = pr;
		this.session = session;
		this.perrep = perrep;
		this.pri = pri;
	}

	@GetMapping(value = "/getPayments")
	public String getAllTransaction(Model model) {
		try {
			Object lc = session.getAttribute("login");
			if (lc == null || (int) lc == 0) {
				model.addAttribute("noaccess", "You need to login first");
				model.addAttribute("login", new LoginClass());
				return "loginPage";
			}
			int access = perrep.checkAccess((int) lc, "/getPayments");
			if (access == 1) {
				LOGGER.info("Retrieving all transactions.");
				model.addAttribute("payments", pri.getAllTransaction());
				LOGGER.info("Retrieved all transactions successfully.");
				return "ViewPayments";
			}
			LOGGER.info("User doesn't have access to the payment section.");
			model.addAttribute("noaccess", "You don't have access to the payment section");
			model.addAttribute("hospitalCount", nhr.getHospitalsCount());
			model.addAttribute("packageCount", pr.getPackagesCount());
			return "dashboard";
		} catch (Exception e) {
			LOGGER.error("Error while retrieving transactions.", e);
			throw e;
		}
	}
}
