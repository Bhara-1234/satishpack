package com.insurance.insuranceCompany.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.contract.DiseaseRepositoryInterface;

@Controller
public class DiseaseController {
    private static final Logger logger = LoggerFactory.getLogger(DiseaseController.class);

    @Autowired
    DiseaseRepositoryInterface dri;

    @GetMapping("/getDisease")
    public String getAllDisease(Model model) {
        try {
            model.addAttribute("diseases", dri.getAllDisease());
            logger.info("Fetched all diseases.");
            logger.trace("Trace message: Fetched all diseases.");
            return "Disease";
        } catch (Exception e) {
            logger.error("Error occurred while fetching diseases: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @PostMapping("/addDisease")
    @ResponseBody
    public String addDisease(@RequestParam String name, String ICDCode, String Description) {
        try {
            String message = dri.addDisease(name, ICDCode, Description, "Active");
            logger.info("Added new disease: {}", name);
            logger.trace("Trace message: Added new disease: {}", name);
            return message;
        } catch (Exception e) {
            logger.error("Error occurred while adding a new disease: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error message.
            return "Error adding disease."; // Example: Return an error message
        }
    }

    @PostMapping("/editDisease")
    @ResponseBody
    public String editDisease(@RequestParam String name, String ICDCode, String Description, String Status, Model model) {
        try {
            String message = dri.editDisease(name, ICDCode, Description, Status);
            model.addAttribute("diseases", dri.getAllDisease());
            logger.info("Edited disease: {}", name);
            logger.trace("Trace message: Edited disease: {}", name);
            return message;
        } catch (Exception e) {
            logger.error("Error occurred while editing disease: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error message.
            return "Error editing disease."; // Example: Return an error message
        }
    }

    @PostMapping("/deleteDisease")
    @ResponseBody
    public String deleteDisease(@RequestParam String name) {
        try {
            String message = dri.deleteDisease(name);
            logger.info("Deleted disease: {}", name);
            logger.trace("Trace message: Deleted disease: {}", name);
            return message;
        } catch (Exception e) {
            logger.error("Error occurred while deleting disease: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error message.
            return "Error deleting disease."; // Example: Return an error message
        }
    }
}
