package com.insurance.insuranceCompany.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.insuranceCompany.model.NetworkHospitals;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class NetworkHospitalRestController {
    private static final Logger LOGGER = LoggerFactory.getLogger(NetworkHospitalRestController.class);

    @Autowired
    private NetworkHospitalRepository nr;

    @GetMapping("/jsonhsp")
    public ArrayList<NetworkHospitals> getAllHospitals() {
        try {
            ArrayList<NetworkHospitals> hospitals = nr.getAllHospitals();
            LOGGER.info("Retrieved all network hospitals successfully in JSON format.");
            return hospitals;
        } catch (Exception e) {
            LOGGER.error("Error while retrieving network hospitals in JSON format.", e);
            throw e;
        }
    }
}
