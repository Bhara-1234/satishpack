package com.insurance.insuranceCompany.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.repository.CustomerRepositoryInterface;

@Controller
public class CustomerController {
    private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

    @Autowired
    CustomerRepositoryInterface cri;

    @GetMapping("/getCustomers")
    public String getCustomers(Model model) {
        try {
            model.addAttribute("customers", cri.getAllCustomers());
            logger.info("Fetched all customers.");
            logger.trace("Trace message: Fetching all customers.");
            return "customerList";
        } catch (Exception e) {
            logger.error("Error occurred while fetching customers: {}", e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @GetMapping("/getCustomerDetails")
    public String getCustomerDetails(@RequestParam("IdVal") String Id, Model model) {
        try {
            model.addAttribute("customer", cri.getCustomerId(Integer.parseInt(Id)));
            model.addAttribute("policies", cri.getPolicies(Id));
            logger.info("Fetched customer details for ID: {}", Id);
            logger.trace("Trace message: Fetched customer details for ID: {}", Id);
            return "customerDetails";
        } catch (Exception e) {
            logger.error("Error occurred while fetching customer details for ID {}: {}", Id, e.getMessage());
            // Handle the error appropriately, e.g., return an error page or send an error response.
            return "error"; // Example: Return an error view
        }
    }

    @PostMapping("/updateCStatus")
    @ResponseBody
    public String updateStatus(@RequestParam String Id, String Status) {
        try {
            String message = cri.updateStatus(Integer.parseInt(Id), Status);
            logger.info("Updated customer status for ID: {} with new status: {}", Id, Status);
            logger.trace("Trace message: Updated customer status for ID: {} with new status: {}", Id, Status);
            return message;
        } catch (Exception e) {
            logger.error("Error occurred while updating customer status for ID {}: {}", Id, e.getMessage());
            // Handle the error appropriately, e.g., return an error message.
            return "Error updating status."; // Example: Return an error message
        }
    }
}
