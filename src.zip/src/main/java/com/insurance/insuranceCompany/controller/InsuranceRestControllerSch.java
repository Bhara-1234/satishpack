package com.insurance.insuranceCompany.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.insuranceCompany.model.InsurancePolicy;
import com.insurance.insuranceCompany.model.InsurancePolicySchedule;
import com.insurance.insuranceCompany.repository.InsuranceRepositorySch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class InsuranceRestControllerSch {
    private static final Logger LOGGER = LoggerFactory.getLogger(InsuranceRestControllerSch.class);

    @Autowired
    private InsuranceRepositorySch insuranceRepository;

    @GetMapping("/policy")
    public List<InsurancePolicy> getAllPolicy() {
        try {
            List<InsurancePolicy> policies = insuranceRepository.ListAllPolicy();
            LOGGER.info("Retrieved all insurance policies successfully.");
            return policies;
        } catch (Exception e) {
            LOGGER.error("Error while retrieving all insurance policies.", e);
            throw e;
        }
    }

    @GetMapping("/policySchedule")
    public List<InsurancePolicySchedule> getAllPolicySchedule() {
        try {
            List<InsurancePolicySchedule> policySchedules = insuranceRepository.ListAllPolicySchedules();
            LOGGER.info("Retrieved all insurance policy schedules successfully.");
            return policySchedules;
        } catch (Exception e) {
            LOGGER.error("Error while retrieving all insurance policy schedules.", e);
            throw e;
        }
    }

    @PostMapping(value = "/createpolicy")
    public ResponseEntity<Object> createPolicy(@RequestBody InsurancePolicy u) {
        try {
            insuranceRepository.createNewPolicy(u);
            LOGGER.info("Created a new insurance policy successfully.");
            return new ResponseEntity<>("Insurance policy is created successfully", HttpStatus.CREATED);
        } catch (Exception e) {
            LOGGER.error("Error while creating a new insurance policy.", e);
            return new ResponseEntity<>("Error occurred while creating the insurance policy", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/updatepolicy")
    public ResponseEntity<Object> updatePolicy(@RequestBody InsurancePolicy p) {
        try {
            int result = insuranceRepository.createNewPolicy(p);
            if (result > 0) {
                LOGGER.info("Updated insurance policy successfully.");
                return new ResponseEntity<>("Insurance policy is updated successfully", HttpStatus.OK);
            } else {
                LOGGER.error("Failed to update insurance policy. Policy not found.");
                return new ResponseEntity<>("Insurance policy update failed. Policy not found.", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            LOGGER.error("Error while updating insurance policy.", e);
            return new ResponseEntity<>("Error occurred while updating the insurance policy", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getpolicyid")
    public String getCustomerDetails(@RequestParam("Id") String Id, Model model) {
        try {
            InsurancePolicy policy = insuranceRepository.getPolicyeById(Integer.parseInt(Id));
            model.addAttribute("customer", policy);
            LOGGER.info("Retrieved insurance policy details by ID: " + Id + " successfully.");
            return "customerDetails";
        } catch (Exception e) {
            LOGGER.error("Error while retrieving insurance policy details by ID: " + Id, e);
            throw e;
        }
    }
}
